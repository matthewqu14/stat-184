pset0.py - code for Problem 6 on pset0

pset0.ipynb - identical code to pset0.py, but is more organized into cells 